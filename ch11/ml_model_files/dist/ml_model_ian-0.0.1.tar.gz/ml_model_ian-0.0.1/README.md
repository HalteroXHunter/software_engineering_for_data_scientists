This package provides a simple class to perform hyperparameter tuning on a generic machine learning model.
 The user can input the specifications, including the hyperparameters to use in a search grid, as well as
 the specific machine learning model desired.